using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HRAPPLICATION.Views.Shared
{
    public class _LayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
